using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyContacts.Models;

namespace MyContacts.Controllers
{
    public class HomeController : Controller
    {
        private readonly ContactContext _ctx; // Define as readonly for better performance

        public HomeController(ContactContext ctx)
        {
            _ctx = ctx;
        }

        public IActionResult Index()
        {
            // Fetch contacts along with their categories, ordered by last name
            var contacts = _ctx.Contacts.Include(c => c.Category).OrderBy(c => c.LastName).ToList();
            return View(contacts);
        }
    }
}
